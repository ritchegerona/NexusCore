#!/usr/bin/env bash
set -e

echo "== NexusCore Bootstrap =="

mkdir -p crates/{common,config,logger,filesystem,workspace}
mkdir -p apps/desktop
mkdir -p assets scripts tests knowledge

for c in common config logger filesystem workspace
do
    cargo new crates/$c --lib --vcs none || true
done

echo "Workspace initialized."
